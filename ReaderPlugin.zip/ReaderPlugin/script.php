<?php
/*
Plugin Name: Manga Reader
Description: Allows readers to navigate through manga by clicking on the images or using arrow keys.
Version: 1.0
Author: OpenAI
*/

function manga_reader_scripts() {
  wp_enqueue_script( 'manga-reader-script', plugins_url( 'manga-reader.js', __FILE__ ), array(), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'manga_reader_scripts' );

function manga_reader_shortcode( $atts ) {
  extract( shortcode_atts( array(
    'images' => ''
  ), $atts ) );

  $images = explode( ',', $images );
  $output = '<div class="manga-reader">';
  foreach ( $images as $image ) {
    $output .= '<img src="' . $image . '" class="manga-page" />';
  }
  $output .= '</div>';

  return $output;
}
add_shortcode( 'manga', 'manga_reader_shortcode' );

